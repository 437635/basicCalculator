﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.SetWindowSize(80, 20);
            Console.SetBufferSize(80, 20);
            Console.WriteLine(" C Sharp Calculator");
            Console.WriteLine(" ------------------");
            Console.WriteLine("");
            Console.WriteLine(" [1] Addition          [2] Subtration");
            Console.WriteLine(" [3] Multiplication    [4] Division");
            Console.WriteLine("");
            Console.Write(" Choice >> ");
            String choice;
            choice = Console.ReadLine();
            Console.WriteLine();
            Maths mathTasks = new Maths(); // Create an object called 'mathTasks' of the class 'Maths.cs' to get access to methods within it
            if (choice == "1")
            {
                mathTasks.addition(); // Run 'addition' within 'Maths.cs' if 'addition' is inputted
                Main(args); // At the end of the 'addition' function in 'Maths.cs' it calls a return so by calling Main after where we called
            }              // addition means that when it returns to here it will cycle back to Main

            if (choice == "2")
            {
                mathTasks.subtraction();
                Main(args);
            }

            if (choice == "3")
            {
                mathTasks.multiplication();
                Main(args);
            }

            if (choice == "4")
            {
                mathTasks.division();
                Main(args);
            }

            else
            {
                Main(args);
            }
        }
    }
}

