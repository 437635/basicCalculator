﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicCalculator
{
    class Maths
    {
        public void addition()
        {
            float num1, num2, answer; // Integer variable but allows the use of decimals, can use double instead
            Console.Write(" First Number >> ");
            num1 = float.Parse(Console.ReadLine());
            Console.Write(" Second Number >> ");
            num2 = float.Parse(Console.ReadLine());
            Console.WriteLine("");
            answer = num1 + num2;
            Console.WriteLine(" " + num1 + " + " + num2 + " = " + answer);
            Console.ReadLine();
            return;
        }

        public void subtraction()
        {
            float num1, num2, answer;
            Console.Write(" First Number >> ");
            num1 = float.Parse(Console.ReadLine());
            Console.Write(" Second Number >> ");
            num2 = float.Parse(Console.ReadLine());
            Console.WriteLine("");
            answer = num1 - num2;
            // haha poopoo - George
            Console.WriteLine(" " + num1 + " - " + num2 + " = " + answer);
            Console.ReadLine();
            return;
        }

        public void multiplication()
        {
            float num1, num2, answer;
            Console.Write(" First Number >> ");
            num1 = float.Parse(Console.ReadLine());
            Console.Write(" Second Number >> ");
            num2 = float.Parse(Console.ReadLine());
            Console.WriteLine("");
            answer = num1 * num2;
            Console.WriteLine(" " + num1 + " * " + num2 + " = " + answer);
            Console.ReadLine();
            return;
        }

        public void division()
        {
            float num1, num2, answer;
            Console.Write(" First Number >> ");
            num1 = float.Parse(Console.ReadLine());
            Console.Write(" Second Number >> ");
            num2 = float.Parse(Console.ReadLine());
            Console.WriteLine("");
            answer = num1 / num2;
            Console.WriteLine(" " + num1 + " / " + num2 + " = " + answer);
            Console.ReadLine();
            return;
        }
    }
}
